//
// Created by alex on 01.03.22.
//

#ifndef INC_02_OASENCRAWLER_OOP_FIELD_H
#define INC_02_OASENCRAWLER_OOP_FIELD_H
#include "utils.h"

class Field {
public:
    Field();
    int init();
    int clear();
    enum fieldType type;
};


#endif //INC_02_OASENCRAWLER_OOP_FIELD_H
