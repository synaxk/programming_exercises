//
// Created by alex on 07.03.22.
//

#ifndef INC_02_OASENCRAWLER_OOP_TEST_H
#define INC_02_OASENCRAWLER_OOP_TEST_H


class Test {
public:
    Test();
    Test(char *message, bool result);
    int test();

    char *message;
    bool result;
};


#endif //INC_02_OASENCRAWLER_OOP_TEST_H
