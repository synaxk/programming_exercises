//
// Created by alex on 01.03.22.
//
#include <iostream>

#ifndef INC_02_OASENCRAWLER_OOP_UTILS_H
#define INC_02_OASENCRAWLER_OOP_UTILS_H



struct position {
    int x;
    int y;
};

enum fieldType {
    empty, danger, relic, well
};


#endif //INC_02_OASENCRAWLER_OOP_UTILS_H